$("#Agra").click(function (e) { 
    e.preventDefault();
    $("#targetl").text("Agra");
});

$("#Ahmedabad").click(function (e) { 
    e.preventDefault();
    $("#targetl").text("Ahmedabad");
});
$("#Alleppey").click(function (e) { 
    e.preventDefault();
    $("#targetl").text("Alleppey");
});
$("#Nicobar").click(function (e) { 
    e.preventDefault();
    $("#targetl").text("Andaman and Nicobar");
});
$("#Bangalore").click(function (e) { 
    e.preventDefault();
    $("#targetl").text("Bangalore");
});
$("#Bankok").click(function (e) { 
    e.preventDefault();
    $("#targetl").text("Bankok");
});
$("#Vizag").click(function (e) { 
    e.preventDefault();
    $("#targetl").text("Vizag");
});